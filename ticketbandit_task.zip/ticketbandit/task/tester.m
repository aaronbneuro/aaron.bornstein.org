function [trialrec]=tester(mri, continuity)
% function [trialrec]=tester([mri=0], [continuity])
%
% OUTPUTS:
%
% trialrec - a cellarray of numTrials trialrec structures, each containing
%           bandits - the bandit state - array of structures of (loc, payoff, icon, dim)
%           choice  - choice if bandit trial, memory response if mem probe (1 old 2 new)
%           RT      - reaction time
%           probed  - if the trial was a memory probe, which image was probed before choice; if it was a bandit trial, which image was displayed after choice
%           rwdval  - reward received
%

useScreen = 1;

%% Init
%
disp(' Initializing...');

if (nargin < 1)
    mri = 0;
end

if (nargin < 2)
    continuity = [];
end

global scrH;
global scrW;
global win;

if (useScreen)
    [scrH scrW] = initScreen(mri);
    cbi_ptb_devices;
    [scrH scrW]
else
    scrH = 600;
    scrW = 800;
end

expt_constants;

blankscr(win);
DrawFormattedText(win, ['Initializing...'], 'center', 'center', textcol);
Screen('Flip', win);

if (verbose); tic; end

fn=['../data/primebandit_pilot-' datestr(now,'yyyy.mm.dd') '-' num2str(GetSecs)];
if (simulation)
    fn = [fn '-sim'];
end
if (debugging)
    fn = [fn '-debug'];
end

if (ismac)
    fn=[fn '_mac'];
end

fn=[fn '.mat'];

rand('twister', rand*sum(clock/rand));

global pulses; 
pulses     = [];
onsets     = zeros(1,numTrials);
trialrec   = cell(1,numTrials);
bs         = 0;                                        % System time of expt start, will be set by wait_disdaqs
if (mri)
    jitter     = (round(rand(1,numTrials)*jitsize)-(jitsize/2))*sliceLen;  % Randomly jitter +/- 0-jitsize slices
end
 
%%
% Generate choice trial block lengths (distance between memory probes)
%
for sessIdx = 1:numSess;
    if (verbose); disp(['Generating choice trial lengths for session ' num2str(sessIdx) '...']); end

    % Generate set of choice blocks w\ exponentially distributed lengths of mean=meanCT and min=minCT
    choiceBlocks(sessIdx, 1:numCTblocks) = -ceil(log(rand(1,numCTblocks))./(1/meanCT))+minCT;
    % Trim blocks greater than maxCT
    choiceBlocks(sessIdx, choiceBlocks(sessIdx,:)>maxCT) = maxCT;

    % Pick random blocks to trim until all constraints are satisfied
    while (sum(choiceBlocks(sessIdx,:)) ~= ((numChoice/numSess)-initCT) || ...
            any(choiceBlocks(sessIdx,:)>maxCT) || ...
            any(choiceBlocks(sessIdx,:)<minCT))
        ind            = ceil(rand*(numCTblocks-1));
        choiceBlocks(sessIdx,ind) = choiceBlocks(sessIdx,ind) - sign(sum(choiceBlocks(sessIdx,:)) - ((numCTblocks*meanCT)-initCT));
        if (choiceBlocks(sessIdx,ind) > maxCT); choiceBlocks(sessIdx, ind) = maxCT; end
        if (choiceBlocks(sessIdx,ind) < minCT); choiceBlocks(sessIdx, ind) = minCT; end
    end
end

choiceBlocks = [repmat(initCT, numSess, 1) choiceBlocks];
if (verbose)
    disp(['Generated choice trials lengths, ' ...
          'sum, ' num2str(sum(choiceBlocks'))  ... 
          ' mean ' num2str(mean(choiceBlocks'))]);  
    choiceBlocks
end    

%% 
% Pick memory probe images
% Get the indexes of the memory probe trials
global memProbeTrials;
memProbeTrials      = cumsum(choiceBlocks(:,1:end)+1, 2);
memProbeTrials(2,:) = memProbeTrials(2,:) + restTrials + 1;

memProbeTrials = memProbeTrials';
memProbeTrials = memProbeTrials(:);
    
trialNums       = 1:numTrials;
choiceTrials    = setdiff(trialNums, memProbeTrials);
    
% Randomize the list of memory probe indexes.  
memProbeTrials = memProbeTrials(randperm(length(memProbeTrials)));

global invalidProbeTrials;
global choiceTrials;
% Now take the first invalidProbes # of indexes.  These will be the invalid probes (novel images).
invalidProbeTrials = sort(memProbeTrials(1:invalidProbes));

global availableForMemProbe;
availableForMemProbe = [];

if (debugging)
    save('debug_data.mat', 'choiceTrials', 'trialNums', 'memProbeTrials', 'memProbeTrials', 'invalidProbeTrials', 'choiceBlocks');
end

Priority(MaxPriority(win,'GetSecs','KbCheck'));
HideCursor;

DrawFormattedText(win, ['Initializing...'], 'center', 'center', textcol);
Screen('Flip', win);

global backtick;
backtick       = [];
if (mri)
    backtick   = KbName('`~');
end

global ifi;
ifi = Screen('GetFlipInterval', win);              % Measure flip interval, should be ~1/60

% XXX
if (exist('continuity','var'));
end

global actkeys;
actkeys = ['a' 'b' 'x'];
actkeys = arrayfun(@KbName,actkeys);


%%
% Load images
DrawFormattedText(win, ['Loading images...'], 'center', 'center', textcol);
Screen('Flip', win);

% bandits
banditList = dir([banditdir '/*png']);
banditOrd  = randperm(numBandits);

global bandits;

for thisBandit = 1:length(banditList);
    [bandits(thisBandit).icon bandits(thisBandit).dim] = loadimg([banditdir banditList(banditOrd(thisBandit)).name]);
end

% rewards
global rwdTex;
% [rwdTex{1, 1} rwdTex{1, 2}] = loadimg([rwddir '/quarter.png']);
[rwdTex{1, 1} rwdTex{1, 2}] = loadimg([rwddir '/minus_lincoln.png']);
[rwdTex{2, 1} rwdTex{2, 2}] = loadimg([rwddir '/plus_lincoln.png']);
[rwdTex{3, 1} rwdTex{3, 2}] = loadimg([rwddir '/minus_quarter.png']);
[rwdTex{4, 1} rwdTex{4, 2}] = loadimg([rwddir '/plus_quarter.png']);

% objects
global imageTex;

imgList  = dir([objdir '/*jpg']);
numImgs  = length(imgList);
imageTex = cell(numImgs, 2);
imgord   = randperm(numImgs);

global imgIdx;

if(verbose); disp(['Loading ' num2str(numImgs) ' images...']); end
for imgIdx = 1:length(imgList);
    [imageTex{imgIdx,1} imageTex{imgIdx,2}] = loadimg([objdir imgList(imgord(imgIdx)).name]);
end

imgIdx   = 0;

global trialIdx;
trialIdx = 0;

%%
% Practice
DrawFormattedText(win, ['Here''s a couple of practice turns at the slot machines.'], 'center', 'center', textcol);
Screen('Flip', win);
pause(ITI);
for pti = 1:numPractice;
    % practice variable tells it which kind of reward to give
    trialrec = doChoiceTrial(trialrec, pti);
end

DrawFormattedText(win, ['Okay, now we''re ready to get started!'], 'center', 'center', textcol);
Screen('Flip', win);
pause(ITI);

%%
% Experiment
trialIdx = 0;

pulses_t = [];
if (~mri)
    bs_t = GetSecs;
    if (~simulation)
        DrawFormattedText(win, ['Press any button twice when you''re ready to begin the experiment.'], 'center', 'center', textcol);
        Screen('Flip', win);
        [tk tp pulses] = cbi_ptb_getchoice([], [], pulses, backtick);
        [tk tp pulses] = cbi_ptb_getchoice([], [], pulses, backtick);
    end

    DrawFormattedText(win, ['Ready in ' num2str(disdaqtime) ' seconds...'], 'center', 'center', textcol);
    Screen('Flip', win);

    for ddIdx = 1:disdaqtime;
        pause(1);
        DrawFormattedText(win, num2str(disdaqtime - ddIdx), 'center', 'center', textcol);
        Screen('Flip', win);
    end
else
     [pulses_t bs_t] = cbi_ptb_waitdisdaqs(disdaqtime, backtick);
end


pulses = [pulses; pulses_t];

if (bs == 0)
     bs = bs_t;
end

if (~mri)
    bs = GetSecs;
end

for sessIdx = 1:numSess;
    for cb = 1:size(choiceBlocks, 2);
        % Run the prescribed # of choice trials
        for ct = 1:choiceBlocks(sessIdx, cb);
            trialrec = doChoiceTrial(trialrec);
            if (trialrec{trialIdx}.choice == -1)
                Screen('CloseAll');
                Priority(0);
                save(fn, 'trialrec', 'bs', 'pulses', 'onsets', 'choiceBlocks', 'imgord', 'memProbeTrials', 'invalidProbeTrials', 'availableForMemProbe');
                return;
            end
        end

        % Do a memory probe
        trialrec = doMemTrial(trialrec);
        if (trialrec{trialIdx}.choice == -1)
            Screen('CloseAll');
            Priority(0);
            save(fn, 'trialrec', 'bs', 'pulses', 'onsets', 'choiceBlocks', 'imgord', 'memProbeTrials', 'invalidProbeTrials', 'availableForMemProbe');
            return;
        end
    end

    if (sessIdx < numSess)
        DrawFormattedText(win, ['You''re halfway done!  Take a break.  Stretch, look around, relax for a minute.'], ...
                          'center', scrH*0.2, textcol);
        DrawFormattedText(win, ['When you''ve taken a long enough break, press any key twice to get going again.'], ...
                          'center', scrH*0.75, textcol);
        Screen('Flip', win);
        save(fn, 'trialrec', 'bs', 'pulses', 'onsets', 'choiceBlocks', 'imgord', 'memProbeTrials', 'invalidProbeTrials', 'availableForMemProbe');

        if (~simulation)
            [tk tp pulses] = cbi_ptb_getchoice([], [], pulses, backtick);
            [tk tp pulses] = cbi_ptb_getchoice([], [], pulses, backtick);
        end
        blankscr(win);
        pause(ITI);

        DrawFormattedText(win, ['Ready in ' num2str(disdaqtime) ' seconds...'], 'center', 'center', textcol);
        Screen('Flip', win);
        for ddIdx = 1:disdaqtime;
            pause(1);
            DrawFormattedText(win, num2str(disdaqtime - ddIdx), 'center', 'center', textcol);
            Screen('Flip', win);
        end
    end
end

% Save now
save(fn, 'trialrec', 'bs', 'pulses', 'onsets', 'choiceBlocks', 'imgord', 'memProbeTrials', 'invalidProbeTrials', 'availableForMemProbe');

%%
% Post-task: Memory test, reward delivery
[totrwd memRec] = doPostTest(trialrec);

% Save now
save(fn, 'trialrec', 'bs', 'pulses', 'onsets', 'choiceBlocks', 'imgord', 'memProbeTrials', 'invalidProbeTrials', 'availableForMemProbe', 'memRec', 'totrwd');

% Select two random reward rounds from the memory probes
rp     = randperm(length(memRec));
totrwd = 0;

for rpIdx = 1:2;
    isCorrect = memRec(rp(rpIdx), end)>0;
    addRwd    = 0;

    % Only reward them if they got the probe right.
    if (memRec(rp(rpIdx), 3) == max(rwdVal))
        if (isCorrect)
            addRwd = max(rwdVal);
        else
            addRwd = 0;
        end
    else
        if (isCorrect)
            addRwd = min(rwdVal)/2;
        else
            addRwd = min(rwdVal);
        end
    end
        
    totrwd = totrwd + addRwd;
end

% and add in all the memory rewards
memTrials   = find(cellfun(@(x)(isempty(x.bandits)), trialrec));
mrwd        = []; for mt = 1:length(memTrials); mrwd(end+1) = trialrec{memTrials(mt)}.rwdval; end

totrwd      = totrwd + sum(mrwd);
    
% Save now
save(fn, 'trialrec', 'bs', 'pulses', 'onsets', 'choiceBlocks', 'imgord', 'totrwd', 'memProbeTrials', 'invalidProbeTrials', 'availableForMemProbe', 'memRec');

DrawFormattedText(win, ['All done!  You won $' ...
                        num2str(totrwd-sum(mrwd), '%.2f') ...
                        ' plus $' ...
                        num2str(sum(mrwd), '%.2f') ...
                        ' for the memory tests, so $' ...
                        num2str(totrwd, '%.2f') ...
                        '  total.  Wait for the experimenter.'], ...
                        'center', 'center', textcol);

Screen('Flip', win);

if (verbose); toc; end

if (~simulation)
    [keys wp pulses] = cbi_ptb_getchoice([],actkeys,pulses,backtick);
    [keys wp pulses] = cbi_ptb_getchoice([],actkeys,pulses,backtick);
end

%% Cleanup. 
% 
Screen('CloseAll');
Priority(0);
