function [cat img] = pickImage(cdist)
% function [cat img] = pickImage(cdist)
% 
% Select category from the supplied distribution, image randomly
%

global verbose;
global numImgs;

if (isscalar(cdist))
    ri        = zeros(1,4);
    ri(cdist) = 1;
    cdist     = ri;
end

p = rand;
for j=1:length(cdist);
    if (p < sum(cdist(1:j)))
        cat = j;
        if (verbose>1); disp(['p=' num2str(p) ', printing image ' num2str(j)]); end
        break;
    end
end

img = ceil(rand(1)*numImgs);



