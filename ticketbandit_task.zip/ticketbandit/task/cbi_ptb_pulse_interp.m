function pulses2 = cbi_ptb_pulse_interp(pulses,TR)

%Interpolate pulse vector to insert pulse times that weren't collected.
%
%USAGE: pulses2 = cbi_ptb_pulse_interp(pulses,TR)
%
%INPUTS:
%   pulses - vector of pulse times
%   TR - repetition time (this can be in arbitrary units, as long as they are the same as the pulse times)
%
%OUTPUTS:
%   pulses2 - vector of interpolated pulse times
%
%Sam Gershman, Dec 2007

d = diff(pulses);
f = find(d>1.5*TR);

pulses2 = pulses(1);
for i = 2:length(pulses);
    h = pulses(i) - pulses(i-1);
    j = ceil(h ./ (1.5.*TR));
    if j > 1
        x = pulses(i-1) + cumsum(repmat(TR,j,1));
        pulses2 = [pulses2; x];
    end
    if pulses(i) - pulses2(end) > (TR.*0.5);
        pulses2 = [pulses2; pulses(i)];
    end
end