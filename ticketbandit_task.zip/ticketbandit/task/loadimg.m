function [i s] = loadimg(f)
global win

[rgb m a] = imread(f);
s = size(rgb);

i = Screen('MakeTexture', win, rgb);

