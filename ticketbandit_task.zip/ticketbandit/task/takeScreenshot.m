function takeScreenshot(win, outfn)
% function takeScreenshot(win, outfn)
%
% Write the specified PTB window to the specified filename
%
% - Aaron Bornstein <aaronb@nyu.edu> 02.28.2009
%

global takeShots;

if (takeShots)
    img = Screen('GetImage', win);

    fmt = outfn(end-2:end);
    imwrite(img, outfn, fmt);
end
