function [c,when,pulses] = cbi_ptb_getchoice(timeout,keycodes,pulses,backtick,D)

%Get a button press.
%
%USAGE: [c,when,pulses] = cbi_ptb_getchoice([timeout],[keycodes],[pulses],[backtick],[D])
%
%OPTIONAL INPUTS:
%   timeout - how long the subject has to make a response (sec), relative to the time the function is called (default: forever)
%   keycodes - vector of keycode numbers for responses (default: all buttons); see psychfmri_buttoncodes
%   pulses - vector of pulses, to which newly collected pulses will be concatenated;
%            this should be a column vector (default: [])
%   backtick - keycode for the back tick (default: KbName('`~'))
%   D - device indices to poll (default: all keyboard devices, including button-box)
%
%OUTPUTS:
%   c - choice (index of the keycodes vector)
%   when - time of choice (in system time)
%   pulses - vector of pulse times collected while waiting (in system time)
%
%Sam Gershman, Dec 2007

if nargin < 5 || isempty(D)
    D = cbi_ptb_devices;
end

if nargin < 4; try backtick = KbName('`~'); catch backtick = []; end; end
if nargin < 3; pulses = []; end
if nargin < 2; keycodes = []; end
if nargin < 1 || isempty(timeout); timeout = Inf; end

timeout = timeout + GetSecs;                       %set timeout relative to current time
keydown = 1;
while any(keydown) && (GetSecs < timeout);   %make sure a key is not held down
    WaitSecs(0.005);
    keydown = [];
    for d = D
        keydown = [keydown KbCheck(d)];
    end
end

%now get a key
c = -1; k0 = []; when = [];
while c < 0 && (GetSecs < timeout)
    WaitSecs(0.005);
    [key, w, keycode] = cbi_ptb_kbcheck(D);
    if key
        keycode = find(keycode);
        when = w;
        if length(keycode) == 1;
            if ~isempty(backtick) && keycode == backtick && isempty(k0); %collect scanner pulses
                pulses = [pulses; when];
            elseif ~isempty(keycodes)
                c = find(keycodes==keycode);
                if isempty(c); c = -1; end               %ignore response if the wrong key is pressed
            elseif isempty(keycodes)
		break;					 %done
	    end
        end
    end
    k0 = keycode;
end
pulses = pulses(pulses>=0);                         %get rid of weird negative numbers, if there are any
