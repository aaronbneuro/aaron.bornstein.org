%
% Constants used by both analysis and task components
%
%

%%
% Options
global takeShots;   % Take screenshots?
takeShots  = 0;

global debugging;
debugging  = 0;

global verbose;
verbose    = 2;

global simulation;
simulation = 0;

%%
% Constants
paramdir    = ['../'];
stimdir     = [paramdir 'stim/'];
objdir      = [stimdir 'objects/'];
banditdir   = [stimdir 'bandits/'];
rwddir      = [stimdir 'rewards/'];

global bgcol;
global textcol;
global bordercol;
bgcol     = [0 0 0];
textcol   = [230 230 230];
bordercol = [170 170 170];

% Standard image size
imgH      = 300;
imgW      = 300;

global bandits;
numBandits = 2;
payoffs    = [0.6 0.4];
payoffs    = payoffs(randperm(numBandits));

global payoffBounds;
global driftRate;

payoffBounds  = [0.3 0.7];
driftRate     = 0.1;

for thisBandit = 1:numBandits;
    bandits(thisBandit).loc     = [];
    bandits(thisBandit).payoff  = payoffs(thisBandit);
end

global scrH;
global scrW;

% Center of the bandit images (x, y)
bandits(1).loc  = [(scrW*(1/4))-(imgW/2) (scrH*(1/4))-(imgH/2) ...
                   (scrW*(1/4))+(imgW/2) (scrH*(1/4))+(imgH/2)];

bandits(2).loc  = [(scrW*(3/4))-(imgW/2) (scrH*(1/4))-(imgH/2) ...
                   (scrW*(3/4))+(imgW/2) (scrH*(1/4))+(imgH/2)];

global imgloc;
imgloc          = [(scrW*(1/4))-(imgW/2) (scrH*(3/4))-(imgH/2) ...
                   (scrW*(1/4))+(imgW/2) (scrH*(3/4))+(imgH/2)];

rwdloc          = [(scrW*(1/2))-(imgW/2) (scrH*(0.9))-(imgH/2) ...
                   (scrW*(1/2))+(imgW/2) (scrH*(0.9))+(imgH/2)];

global numTrials;
% Block lengths (# of trials)
numChoice      = 130;
numProbes      = 30;
invalidProbes  = 6;                     % Just enough to keep them on their feet
numTrials      = numChoice + numProbes;
restTrials     = 80;                    % Number of trials between rests
numSess        = ceil(numTrials/restTrials);
numPractice    = 2;

numCTblocks    = numProbes/numSess;     % Number of 'blocks' of choice trials per session (equals # of memory probes in a session)

initCT         = 10;                    % Ensure there are at least this many bandit trials before first memory probe
minCT          = 2;                     % Shortest number of choice trials between memory probes
meanCT         = ((numChoice/numSess)/numCTblocks);        % Average number of choice trials between memory probes
maxCT          = 5;                     % Length of longest block between memory probes (besides initial)


% Trial lengths (sec)
global maxChoiceLen;
global rwdDispLen;
global studyLen;
global ITI;
global maxProbeLen;
maxChoiceLen   = 4;
rwdDispLen     = 2;
studyLen       = 4;
ITI            = 2;
maxProbeLen    = 4;

disdaqtime     = 4;

if (debugging)
    rwdDispLen     = 0.01;
    studyLen       = 0.01;
    ITI            = 0.01;

    disdaqtime     = 0;
end

totalTime      = numChoice*(maxChoiceLen+rwdDispLen+studyLen) + numProbes*(maxProbeLen+rwdDispLen) + numTrials*ITI;


global rwdVal;
global memRwd;
% Descriptive parameters
rwdVal         = [-5 5];              % Possible reward values to assign
memRwd         = 0.25;                % Reward for a correct memory

% Analysis constants
BADTRIAL       = -1;
BADPC          = 0.5;
