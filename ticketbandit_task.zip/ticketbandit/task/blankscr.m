function blankscr(win);
% function blankscr(win);
%
% Blank screen
%

global bgcol;

Screen('FillRect', win, bgcol);
Screen('Flip', win);


