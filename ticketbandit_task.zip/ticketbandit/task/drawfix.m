function drawfix(win);
% function drawfix(win);
%
% Blank screen
%

global textcol;

DrawFormattedText(win, '+', 'center', 'center', textcol);
Screen(win, 'Flip');

