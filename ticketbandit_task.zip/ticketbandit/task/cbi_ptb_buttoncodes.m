function keycodes = cbi_ptb_buttoncodes(buttons)

%Get keycodes.
%
%USAGE: keycodes = cbi_ptb_buttoncodes([buttons])
%
%OPTIONAL INPUTS:
%   buttons - vector of numbers corresponding to which buttons you want (the buttons on the button box
%             are numbered); they can be in any order (default: all of the buttons, 1:10)
%
%NOTE: the '0' key is treated as key # 10
%
%Sam Gershman, Dec 2007

try
    choices = [KbName('1!'),KbName('2@'),KbName('3#'),KbName('4$'),KbName('5%'),KbName('6^'),KbName('7&'),KbName('8*'),KbName('9('),KbName('0)')];
catch
    choices = [KbName('1'),KbName('2'),KbName('3'),KbName('4'),KbName('5'),KbName('6'),KbName('7'),KbName('8'),KbName('9'),KbName('0')];
end

if nargin < 1; buttons = 1:length(choices); end

keycodes = choices(buttons);
