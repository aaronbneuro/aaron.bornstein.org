function pulses = cbi_ptb_wait(timeout,pulses,backtick,D)

%Wait for a while, but collect pulse times while waiting.
%
%USAGE: pulses = cbi_ptb_wait(timeout,[pulses],[backtick],[D])
%
%INPUTS:
%   timeout - how long to wait (seconds)
%
%OPTIONAL INPUTS:
%   pulses - vector of pulses, to which newly collected pulses will be concatenated;
%            this should be a column vector (default: [])
%   backtick - keycode for the back tick (default: KbName('`~'))
%   D - device indices to poll (default: all keyboard devices, including button-box)
%
%OUTPUTS:
%   pulses - vector of pulse times collected while waiting (in system time)
%
%Sam Gershman, Dec 2007

if nargin < 4 || isempty(D)
    D = cbi_ptb_devices;
end

if nargin < 3; try backtick = KbName('`~'); catch backtick = []; end; end
if nargin < 2; pulses = []; end

% [c,when,pulses] = cbi_ptb_getchoice(timeout,[],pulses,backtick);

k0 = [];
t = GetSecs;                        %get the current time
timeout = timeout + t;              %set timeout relative to system time
while t < timeout
    WaitSecs(0.005);
     for d = D
         [r t k] = KbCheck(d);       %look for scanner pulse
     end
     k = find(k);
     if ~isempty(backtick) && length(k)==1 && k==backtick && isempty(k0);    %make sure to sample each pulse only once
         pulses = [pulses; t];
     end
     k0 = k;
end
pulses = pulses(pulses>=0);         %get rid of weird negative numbers, if there are any
