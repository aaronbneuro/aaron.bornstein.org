function [r T K] = cbi_ptb_kbcheck(D)

K = [];
T = inf;
for d = D
    [r t k] = KbCheck(d);
    if r
        if isempty(K)
            K = k;
        else
            K = K | k;
        end
        T = min(T, t);
    end
end
r = ~isempty(K);
