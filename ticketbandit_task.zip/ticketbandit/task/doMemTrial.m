function [trialrec] = doMemTrial(trialrec)
% function [trialrec] = doMemTrial(trialrec)
%
% Perform a single memory probe trial
%
% Return the output in an updated trialrec structure
%

%%
% Shared variables
global pulses;
global backtick;
global bandits;
global actkeys;
global verbose;
global debugging;
global simulation;

global numTrials;

global ifi;
global win;
global scrH;
global scrW;
global textcol;

global imageTex;
global trialIdx;
global imgIdx;
global imgloc;
global rwdTex;
global rwdloc;

global studyLen;
global maxProbeLen;
global rwdDispLen;
global memRwd;
global ITI;

trialIdx = trialIdx + 1;
trialrec{trialIdx}.bandits = [];
trialrec{trialIdx}.choice  = -1;

%%
% 1. Decide if this is an invalid probe.
% If so, take the next image off the stack.
% If not, pick an image that has already been displayed in a choice trial.
global invalidProbeTrials;
global choiceTrials;
global availableForMemProbe;

isValid = 1;

if (ismember(trialIdx, sort(invalidProbeTrials)))
    isValid = 0;
    imgIdx = imgIdx + 1;
    trialrec{trialIdx}.probed     = imageTex{imgIdx, 1};
    trialrec{trialIdx}.probed_dim = imageTex{imgIdx, 2};

    if (verbose>1)
        disp(['Invalid probe trial, probing image number ' num2str(imgIdx)]);
    end
else
    % Pick an image from the available list
    probeIdx = ceil(rand(1)*length(availableForMemProbe));

    if (verbose>1)
        disp(['Valid probe trial, probing image number ' num2str(availableForMemProbe(probeIdx))]);
    end

    % Use that image
    trialrec{trialIdx}.probed     = imageTex{availableForMemProbe(probeIdx), 1};
    trialrec{trialIdx}.probed_dim = imageTex{availableForMemProbe(probeIdx), 2};

    if (verbose>1)
        availableForMemProbe
    end
    % Delete it from the available list
    availableForMemProbe          = [availableForMemProbe(1:probeIdx-1) availableForMemProbe((probeIdx+1):end)];
    if (verbose>1)
        availableForMemProbe
    end

if(0)
    % Pick a choice trial that has already happened
    selectSet = find(choiceTrials<trialIdx);
    cti = ceil(rand(1)*length(selectSet));
    cti = choiceTrials(selectSet(cti));

    % Use that image
    trialrec{trialIdx}.probed     = trialrec{cti}.probed;
    trialrec{trialIdx}.probed_dim = trialrec{cti}.probed_dim;

    % Now set that trial to an invalid number, so it doesn't get probed again
    choiceTrials(choiceTrials==cti) = numTrials+1;
end
end

%%
% 2. Display image
%

imgW    = trialrec{trialIdx}.probed_dim(2);
imgH    = trialrec{trialIdx}.probed_dim(1);
imgloc          = [(scrW*(1/2))-(imgW/2) (scrH*(1/2))-(imgH/2) ...
                   (scrW*(1/2))+(imgW/2) (scrH*(1/2))+(imgH/2)];
Screen('DrawTexture', win, trialrec{trialIdx}.probed, [0 0 imgW imgH], imgloc);
DrawFormattedText(win, 'We found this ticket on the floor.  Is it yours?', ...
                        'center', scrH*0.05, textcol);
DrawFormattedText(win, 'a = Yes, b = No', ...
                        'center', scrH*0.75, textcol);
Screen('Flip', win);
takeScreenshot(win, '5_memProbe.png');

onset     = GetSecs;
endtm     = onset;
wp        = onset; % when pressed

keys        = 0;
pressed     = 0;
lastpressed = 0;

if (simulation)
    lastpressed = ceil(rand(1)*2);
end

while ((endtm - onset < maxProbeLen) && (lastpressed == 0))
    timeout          = maxProbeLen - (endtm - onset);
    [keys wp pulses] = cbi_ptb_getchoice(timeout, actkeys, pulses, backtick);

    if (any(keys(keys == length(actkeys))))
        if (verbose); disp(['Got exit']); end
        trialrec{trialIdx}.choice  = -1;
        return;
    end

    endtm   = GetSecs;
    if (keys == -1)
        if (verbose>1); disp(['Got no keypress!']); end
        continue;
    end
    pressed = keys;

    % Record buttonpress, skipping repeated events.
    if (size(pressed,1)>1); pressed = pressed(1); end
    if (~isequal(pressed,lastpressed))
        if (verbose>1); disp(['Got keypress ' num2str(pressed)]); end
        lastpressed = pressed;
    end
end

if (lastpressed == 0)
    % Timed out, so they get it wrong.
    if (isValid)
        lastpressed = 2;
    else
        lastpressed = 1;
    end
end

memResponse = lastpressed;
trialrec{trialIdx}.choice = memResponse;
trialrec{trialIdx}.RT     = wp - onset;

if (0)          % Don't wait before displaying the reward.
% Got keypress, so clear off the memory probe question
imgW    = trialrec{trialIdx}.probed_dim(2);
imgH    = trialrec{trialIdx}.probed_dim(1);
Screen('DrawTexture', win, trialrec{trialIdx}.probed, [0 0 imgW imgH], imgloc);
Screen('Flip', win);

% How much time should the image stay on screen?
thistm  = GetSecs;
timeout = maxProbeLen - ((thistm-onset)+ifi);

if(verbose>1); disp(['Displaying probe image for ' ...
                     num2str(timeout) ' seconds more.']); end
if (timeout > 0 && ~debugging)
    pulses  = cbi_ptb_wait(timeout,pulses,backtick);
end

end

%%
% 3. Display reward (persist image)
%
imgW    = trialrec{trialIdx}.probed_dim(2);
imgH    = trialrec{trialIdx}.probed_dim(1);
Screen('DrawTexture', win, trialrec{trialIdx}.probed, [0 0 imgW imgH], imgloc);
if (memResponse == 1 && isValid || ...
    memResponse == 2 && ~isValid)
    isrwded = 1;
else
    isrwded = -1;
end

if (isrwded > 0)
    resultString = 'Right!';
else
    resultString = 'Wrong!';
end

trialrec{trialIdx}.rwdval = memRwd * isrwded;
if (0)
    DrawFormattedText(win, [resultString '  $' num2str(trialrec{trialIdx}.rwdval, ...
                            '%.2f')], ...
                            'center', scrH*0.75, textcol); 
end
isrwded = (isrwded>0);

imgW    = rwdTex{isrwded+3, 2}(2);
imgH    = rwdTex{isrwded+3, 2}(1);
rwdloc          = [(scrW*(1/2))-(imgW/2) (scrH*(0.8))-(imgH/2) ...
                   (scrW*(1/2))+(imgW/2) (scrH*(0.8))+(imgH/2)];

Screen('DrawTexture', win, rwdTex{isrwded+3, 1}, [0 0 imgW imgH], rwdloc);
Screen('Flip', win);
if (isrwded)
    takeScreenshot(win, '6_memReward_Positive.png');
else
    takeScreenshot(win, '6_memReward_Negative.png');
end

pulses  = cbi_ptb_wait(rwdDispLen, pulses, backtick);
blankscr(win);
pulses  = cbi_ptb_wait(ITI, pulses, backtick);
