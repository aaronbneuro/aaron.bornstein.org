function drawbox(offon, rect, bg)
% function drawbox(offon, rect, bg)
% 

global win;
global scrH; 
global scrW;
global imgH;
global imgW;
global bgcol;
global bordercol;

r  = 0;
pw = 20;

if (offon)
    bc = bordercol;
else
    bc = bgcol;
end

if (nargin > 2)
    pw = 0;
    bc = [255 255 255];
end

if (nargin > 1)
    r = rect;
end

if (~r)
    r = [(scrW/2 - imgW/2 - pw) (scrH/2 - imgH/2 - pw) ...
         (scrW/2 + imgW/2 + pw) (scrH/2 + imgH/2 + pw)];
end


Screen(win, 'FillRect', bc, r);
