function k = kbget(to)
% read a key with timeout to

[r t k] = KbCheck;
while ~r && t < to
    WaitSecs(0.005);
    [r t k] = KbCheck;
end
