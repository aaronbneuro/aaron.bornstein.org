function drawimg(img)
% function drawimg(img)

global win;

Screen('DrawTexture', win, img);
Screen('Flip', win);
