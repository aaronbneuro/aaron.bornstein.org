function [totrwd memRec] = doPostTest(trialrec)
% function [totrwd memRec] = doPostTest
%
% Do the post-experiment memory test
%
% Return the output in an updated memRec structure
%

%%
% Shared variables
global pulses;
global backtick;
global bandits;
global actkeys;
global verbose;
global debugging;
global simulation;

global numTrials;

global ifi;
global win;
global scrH;
global scrW;
global textcol;

global imageTex;
global trialIdx;
global imgIdx;
global imgloc;
global rwdTex;
global rwdloc;
global rwdVal;

global studyLen;
global maxChoiceLen;
global maxProbeLen;
global rwdDispLen;
global memProbeTrials;
global ITI;

totrwd            = 0;
% Record of post-experiment memory test: index
memRec            = [];

% Select memory probe trials from the randomized list of trials.
memPairs          = {};
for mpi = 1:length(memProbeTrials)
    if (verbose)
        disp(['Checking trial ' num2str(memProbeTrials(mpi))]);
    end
    probed = trialrec{memProbeTrials(mpi)}.probed;

    ft = [];
    for thisIdx = 1:(memProbeTrials(mpi)-1);
        if (probed == trialrec{thisIdx}.probed)
            ft(1) = thisIdx;
            ft(2) = trialrec{thisIdx}.rwdval;
            break;
        end
    end

    if (~isempty(ft))
        memPairs{end+1} = [memProbeTrials(mpi) ft(1) ft(2)];
    end
end

blankscr(win);
DrawFormattedText(win, 'Now we''re going to check to see if those tickets are yours.', ...
                       'center', 'center', textcol);
Screen('Flip', win);
if (~simulation)
    pause(ITI);
end

% Test each mem probe trial
for testIdx = 1:length(memPairs)
    % Index of current trial, index of evoked bandit, reward value received, correct (1)/incorrect (-1) response on bandit test, reward test
    memRec(testIdx,:) = [memPairs{testIdx}(1) memPairs{testIdx}(2) memPairs{testIdx}(3) 0 0];

    lastpressed = 0;

    % First, test the bandit
    while(lastpressed == 0)
        DrawFormattedText(win, ['Which machine did you get this ticket from (a = Left, b = Right)?'], ...
                                'center', scrH*0.05, textcol);
        imgW    = imageTex{trialrec{memPairs{testIdx}(2)}.probed, 2}(2);
        imgH    = imageTex{trialrec{memPairs{testIdx}(2)}.probed, 2}(1);
        imgloc  = [(scrW*(1/2))-(imgW/2) (scrH*(1/2))-(imgH/2) ...
                   (scrW*(1/2))+(imgW/2) (scrH*(1/2))+(imgH/2)];
%        Screen('DrawTexture', win, imageTex{trialrec{memPairs{testIdx}(2)}.probed, 1}, [0 0 imgW imgH], imgloc);       XXX: This was a bug in all of the collected subjects thru 03.11.2013
        Screen('DrawTexture', win, trialrec{memPairs{testIdx}(2)}.probed, [0 0 imgW imgH], imgloc);
        Screen('Flip', win);
        takeScreenshot(win, '7_banditTest.png');

        lastpressed = 0;

        onset     = GetSecs;
        endtm     = onset;
        wp        = onset; % when pressed

        keys        = 0;
        pressed     = 0;

        if (simulation)
            lastpressed = ceil(rand(1)*2);
        end

        while ((endtm - onset < maxChoiceLen) && (lastpressed == 0))
            timeout          = maxChoiceLen - (endtm - onset);
            [keys wp pulses] = cbi_ptb_getchoice(timeout, actkeys, pulses, backtick);

            if (any(keys(keys == length(actkeys))))
                if (verbose); disp(['Got exit']); end
                return;
            end

            endtm   = GetSecs;
            if (keys == -1)
                if (verbose>1); disp(['Got no keypress!']); end
                continue;
            end
            pressed = keys;

            % Record buttonpress, skipping repeated events.
            if (size(pressed,1)>1); pressed = pressed(1); end
            if (~isequal(pressed,lastpressed))
                if (verbose>1); disp(['Got keypress ' num2str(pressed)]); end
                lastpressed = pressed;
            end
        end

        if (lastpressed == 0)
            % Timed out
            DrawFormattedText(win, 'Are you there?  Please respond to this question! It determines your reward.', ...
                              'center', 'center', textcol);
            Screen('Flip', win);
            pause(ITI);

        end
    end

    if (lastpressed == trialrec{memPairs{testIdx}(2)}.choice)
        memRec(testIdx, 4) = 1;

        DrawFormattedText(win, ['Correct!'], ...
                          'center', 'center', textcol);
        Screen('Flip', win);
        pause(ITI);
    else
        DrawFormattedText(win, ['Sorry, that''s not right.  Let''s try another ticket.'], ...
                          'center', 'center', textcol);
        Screen('Flip', win);
        pause(ITI);
        memRec(testIdx, 4) = -1;

        % Don't bother with the reward test.
        continue;
    end

    lastpressed = 0;

    % Next, test the reward
    while (lastpressed == 0)
        DrawFormattedText(win, ['How much is this ticket worth (a = -$5, b = $5)?'], ...
                                'center', scrH*0.05, textcol);
        imgW    = imageTex{trialrec{memPairs{testIdx}(2)}.probed, 2}(2);
        imgH    = imageTex{trialrec{memPairs{testIdx}(2)}.probed, 2}(1);
        imgloc          = [(scrW*(1/2))-(imgW/2) (scrH*(1/2))-(imgH/2) ...
                           (scrW*(1/2))+(imgW/2) (scrH*(1/2))+(imgH/2)];
%        Screen('DrawTexture', win, imageTex{trialrec{memPairs{testIdx}(2)}.probed, 1}, [0 0 imgW imgH], imgloc);       XXX: This was a bug in all of the collected subjects thru 03.11.2013
        Screen('DrawTexture', win, trialrec{memPairs{testIdx}(2)}.probed, [0 0 imgW imgH], imgloc);
        Screen('Flip', win);
        takeScreenshot(win, '7a_rewardTest.png');

        lastpressed = 0;

        onset     = GetSecs;
        endtm     = onset;
        wp        = onset; % when pressed

        keys        = 0;
        pressed     = 0;

        if (simulation)
            lastpressed = ceil(rand(1)*2);
        end

        while ((endtm - onset < maxChoiceLen) && (lastpressed == 0))
            timeout          = maxChoiceLen - (endtm - onset);
            [keys wp pulses] = cbi_ptb_getchoice(timeout, actkeys, pulses, backtick);
            if (any(keys(keys == length(actkeys))))
                if (verbose); disp(['Got exit']); end
                return;
            end

            endtm   = GetSecs;
            if (keys == -1)
                if (verbose>1); disp(['Got no keypress!']); end
                continue;
            end
            pressed = keys;

            % Record buttonpress, skipping repeated events.
            if (size(pressed,1)>1); pressed = pressed(1); end
            if (~isequal(pressed,lastpressed))
                if (verbose>1); disp(['Got keypress ' num2str(pressed)]); end
                lastpressed = pressed;
            end
        end

        if (lastpressed == 0)
            % Timed out
            DrawFormattedText(win, 'Are you there?  Please respond to this question! It determines your reward.', ...
                              'center', 'center', textcol);
            Screen('Flip', win);
            pause(ITI);
        end
    end

    if (rwdVal(lastpressed) == trialrec{memPairs{testIdx}(2)}.rwdval)
        % Correct
        memRec(testIdx, 5) = 1;

        newVal = max(rwdVal);
        if (rwdVal(lastpressed) == min(rwdVal))
            newVal = min(rwdVal)/2;
        end
        DrawFormattedText(win, ['Correct!  This ticket will be worth $' num2str(newVal) ' if it is drawn.'], ...
                                'center', 'center', textcol);
        Screen('Flip', win);
        takeScreenshot(win, '8_banditTest_correct.png');
    else
        memRec(testIdx, 5) = -1;

        % Incorrect
        newVal = min(rwdVal);
        if (rwdVal(lastpressed) == max(rwdVal))
            newVal = 0;
        end
        DrawFormattedText(win, ['Sorry, that''s not right.  This ticket will be worth $' num2str(newVal) ' if it is drawn.'], ...
                                'center', 'center', textcol);
        Screen('Flip', win);
        takeScreenshot(win, '8_banditTest_incorrect.png');
    end

    if (~simulation)
        pause(ITI);
    end
end
