function [trialrec] = doChoiceTrial(trialrec, practice)
% function [trialrec] = doChoiceTrial(trialrec, [practice=0])
%
% Perform a single trial involving a choice among the specified bandits
%
% Return the output in an updated trialrec structure
%

%%
% Shared variables
global verbose;
global debugging;
global simulation;

global pulses;
global backtick;
global bandits;
global actkeys;
global driftRate;

global ifi;
global win;
global scrH;
global scrW;
global textcol;

global imageTex;
global trialIdx;
global imgIdx;
global imgloc;
global rwdTex;
global rwdloc;

global studyLen;
global maxChoiceLen;
global rwdDispLen;
global rwdVal;
global ITI;

global payoffBounds;
global availableForMemProbe;

if (nargin < 2)
    practice = 0;
end

%%
% 1. Drift bandits
%
for thisBandit = 1:length(bandits);
    bandits(thisBandit).payoff = bandits(thisBandit).payoff + randn(1)*driftRate;
    % Reflect at bounds
    if (bandits(thisBandit).payoff > payoffBounds(2))
        bandits(thisBandit).payoff = payoffBounds(2) - (bandits(thisBandit).payoff - payoffBounds(2));
    end
    if (bandits(thisBandit).payoff < payoffBounds(1))
        bandits(thisBandit).payoff = payoffBounds(1) + (payoffBounds(1) - bandits(thisBandit).payoff);
    end
end

trialIdx = trialIdx + 1;
trialrec{trialIdx}.bandits = bandits;           % Static bandits XXX
trialrec{trialIdx}.choice  = -1;


%%
% 2. Participant chooses
%
lastpressed = 0;

while(lastpressed == 0)
    DrawFormattedText(win, ['Pick a slot machine'], ...
                           'center', scrH*0.05, textcol);

    for thisBandit = 1:length(bandits);
        imgW    = bandits(thisBandit).dim(2);
        imgH    = bandits(thisBandit).dim(1);

        Screen('DrawTexture', win, bandits(thisBandit).icon, [0 0 imgW imgH], bandits(thisBandit).loc);
    end
    Screen('Flip', win);
    takeScreenshot(win, '1_banditDisplay.png');

    onset     = GetSecs;
    endtm     = onset;
    wp        = onset; % when pressed

    keys        = 0;
    pressed     = 0;

    if (simulation)
        lastpressed = ceil(rand(1)*2);
    end

    while ((endtm - onset < maxChoiceLen) && (lastpressed == 0))
        timeout          = maxChoiceLen - (endtm - onset);
        [keys wp pulses] = cbi_ptb_getchoice(timeout, actkeys, pulses, backtick);

        if (any(keys(keys == length(actkeys))))
            if (verbose); disp(['Got exit']); end
            trialrec{trialIdx}.choice  = -1;
            return;
        end

        endtm   = GetSecs;
        if (keys == -1)
            if (verbose>1); disp(['Got no keypress!']); end
            continue;
        end
        pressed = keys;

        % Record buttonpress, skipping repeated events.
        if (size(pressed,1)>1); pressed = pressed(1); end
        if (~isequal(pressed,lastpressed))
            if (verbose>1); disp(['Got keypress ' num2str(pressed)]); end
            lastpressed = pressed;
        end
    end

    if (lastpressed == 0)
        % Timed out
        DrawFormattedText(win, 'Are you there?  Please pick a slot machine.', 'center', 'center', textcol);
        Screen('Flip', win);
        pause(ITI);
    end
end

thisBandit = lastpressed;
trialrec{trialIdx}.choice = thisBandit;
trialrec{trialIdx}.RT     = wp - onset;

imgW    = bandits(thisBandit).dim(2);
imgH    = bandits(thisBandit).dim(1);
Screen('DrawTexture', win, bandits(thisBandit).icon, [0 0 imgW imgH], bandits(thisBandit).loc);
Screen('Flip', win);
takeScreenshot(win, '2_banditChosen.png');

% How much time should the chosen bandit stay on screen?
thistm  = GetSecs;
timeout = maxChoiceLen - ((thistm-onset)+ifi);
timeout = 0.25;                % XXX: As of 10/25, don't persist the bandit image for more than a quarter second.

if(verbose>1); disp(['Displaying chosen bandit for ' ...
                     num2str(timeout) ' seconds more.']); end
if (timeout > 0 && ~debugging)
    pulses  = cbi_ptb_wait(timeout,pulses,backtick);
end

%%
% 3. Display consequent image for trial length (persist bandit image)
%
imgW    = bandits(thisBandit).dim(2);
imgH    = bandits(thisBandit).dim(1);
Screen('DrawTexture', win, bandits(thisBandit).icon, [0 0 imgW imgH], bandits(thisBandit).loc);
% Pick the next image off the stack
imgIdx  = imgIdx + 1;

if (~practice)
    % Make it available for future memory probes
    availableForMemProbe(end+1) = imgIdx;
    if (verbose>1)
        disp(['Displaying image ' num2str(imgIdx)]);
        availableForMemProbe
    end
end

imgW    = imageTex{imgIdx,2}(2);
imgH    = imageTex{imgIdx,2}(1);
imgloc  = [(scrW*(1/2))-(imgW/2) (scrH*(1/2))-(imgH/2) ...
           (scrW*(1/2))+(imgW/2) (scrH*(1/2))+(imgH/2)];
Screen('DrawTexture', win, imageTex{imgIdx,1}, [0 0 imgW imgH], imgloc);
trialrec{trialIdx}.probed     = imageTex{imgIdx, 1};
trialrec{trialIdx}.probed_dim = imageTex{imgIdx, 2};
Screen('Flip', win);
takeScreenshot(win, '3_banditPlusImage.png');

% Do "deep encoding" task (make them press the bandit button again)
lastpressed = 0;
keys        = 0;
pressed     = 0;
if (simulation)
    lastpressed = thisBandit;
end
onset = GetSecs;

while (lastpressed ~= thisBandit)
    timeout          = studyLen;
    [keys wp pulses] = cbi_ptb_getchoice(timeout, actkeys, pulses, backtick);

    if (any(keys(keys == length(actkeys))))
        if (verbose); disp(['Got exit']); end
        trialrec{trialIdx}.choice  = -1;
        return;
    end

    if (keys == -1)
        if (verbose>1); disp(['Got no keypress!']); end
        continue;
    end
    pressed = keys;

    % Record buttonpress, skipping repeated events.
    if (size(pressed,1)>1); pressed = pressed(1); end
    if (~isequal(pressed,lastpressed))
        if (verbose>1); disp(['Got keypress ' num2str(pressed)]); end
        lastpressed = pressed;
    end
end

imgW    = bandits(thisBandit).dim(2);
imgH    = bandits(thisBandit).dim(1);
Screen('DrawTexture', win, bandits(thisBandit).icon, [0 0 imgW imgH], bandits(thisBandit).loc);
boxrect      = imgloc;
boxrect(1:2) = boxrect(1:2) - 20;
boxrect(3:4) = boxrect(3:4) + 20;
drawbox(1, boxrect);
imgW    = imageTex{imgIdx,2}(2);
imgH    = imageTex{imgIdx,2}(1);
imgloc  = [(scrW*(1/2))-(imgW/2) (scrH*(1/2))-(imgH/2) ...
           (scrW*(1/2))+(imgW/2) (scrH*(1/2))+(imgH/2)];
Screen('DrawTexture', win, imageTex{imgIdx,1}, [0 0 imgW imgH], imgloc);
Screen('Flip', win);
takeScreenshot(win, '3a_banditPlusImagePlusBox.png');

boxTime = min(ITI, 0.5);
pause(boxTime);

imgW    = bandits(thisBandit).dim(2);
imgH    = bandits(thisBandit).dim(1);
Screen('DrawTexture', win, bandits(thisBandit).icon, [0 0 imgW imgH], bandits(thisBandit).loc);
imgW    = imageTex{imgIdx,2}(2);
imgH    = imageTex{imgIdx,2}(1);
imgloc  = [(scrW*(1/2))-(imgW/2) (scrH*(1/2))-(imgH/2) ...
           (scrW*(1/2))+(imgW/2) (scrH*(1/2))+(imgH/2)];
Screen('DrawTexture', win, imageTex{imgIdx,1}, [0 0 imgW imgH], imgloc);
Screen('Flip', win);

currTime  = GetSecs;
timeout   = studyLen - (currTime - onset);
if (timeout < 0.5)
    timeout = min(studyLen, 0.5);
end
pulses    = cbi_ptb_wait(timeout, pulses, backtick);

%%
% 4. Display reward (persist bandit image & consequent image)
%
imgW    = bandits(thisBandit).dim(2);
imgH    = bandits(thisBandit).dim(1);
Screen('DrawTexture', win, bandits(thisBandit).icon, [0 0 imgW imgH], bandits(thisBandit).loc);
imgW    = imageTex{imgIdx,2}(2);
imgH    = imageTex{imgIdx,2}(1);
imgloc          = [(scrW*(1/2))-(imgW/2) (scrH*(1/2))-(imgH/2) ...
                   (scrW*(1/2))+(imgW/2) (scrH*(1/2))+(imgH/2)];
Screen('DrawTexture', win, imageTex{imgIdx,1}, [0 0 imgW imgH], imgloc);
if (~practice)
    isrwded = (rand(1)<(bandits(thisBandit).payoff));
else
    isrwded = (practice-1);
end
% trialrec{trialIdx}.rwdval = rwdVal * isrwded;
trialrec{trialIdx}.rwdval = rwdVal(isrwded+1);
imgW    = rwdTex{isrwded+1, 2}(2);
imgH    = rwdTex{isrwded+1, 2}(1);
rwdloc          = [(scrW*(1/2))-(imgW/2) (scrH*(0.8))-(imgH/2) ...
                   (scrW*(1/2))+(imgW/2) (scrH*(0.8))+(imgH/2)];

% Added 12.7, starting with subject 30
if (~isrwded)
    rwdloc(1) = (scrW*(1/3))-(imgW/2);
    rwdloc(3) = (scrW*(1/3))+(imgW/2);
else
    rwdloc(1) = (scrW*(2/3))-(imgW/2);
    rwdloc(3) = (scrW*(2/3))+(imgW/2);
end

Screen('DrawTexture', win, rwdTex{isrwded+1, 1}, [0 0 imgW imgH], rwdloc);
Screen('Flip', win);
if (isrwded)
    takeScreenshot(win, '4_banditPlusImagePlusReward.png');
else
    takeScreenshot(win, '4_banditPlusImageMinusReward.png');
end

% Do "deep encoding" task (make them press the bandit button again)
lastpressed = 0;
keys        = 0;
pressed     = 0;
if (simulation)
    lastpressed = isrwded+1;
end
onset = GetSecs;

while (lastpressed ~= isrwded+1)
    timeout          = studyLen;
    [keys wp pulses] = cbi_ptb_getchoice(timeout, actkeys, pulses, backtick);

    if (any(keys(keys == length(actkeys))))
        if (verbose); disp(['Got exit']); end
        trialrec{trialIdx}.choice  = -1;
        return;
    end

    if (keys == -1)
        if (verbose>1); disp(['Got no keypress!']); end
        continue;
    end
    pressed = keys;

    % Record buttonpress, skipping repeated events.
    if (size(pressed,1)>1); pressed = pressed(1); end
    if (~isequal(pressed,lastpressed))
        if (verbose>1); disp(['Got keypress ' num2str(pressed)]); end
        lastpressed = pressed;
    end
end

imgW    = bandits(thisBandit).dim(2);
imgH    = bandits(thisBandit).dim(1);
Screen('DrawTexture', win, bandits(thisBandit).icon, [0 0 imgW imgH], bandits(thisBandit).loc);
imgW    = imageTex{imgIdx,2}(2);
imgH    = imageTex{imgIdx,2}(1);
imgloc  = [(scrW*(1/2))-(imgW/2) (scrH*(1/2))-(imgH/2) ...
           (scrW*(1/2))+(imgW/2) (scrH*(1/2))+(imgH/2)];
Screen('DrawTexture', win, imageTex{imgIdx,1}, [0 0 imgW imgH], imgloc);
imgW    = rwdTex{isrwded+1, 2}(2);
imgH    = rwdTex{isrwded+1, 2}(1);
rwdloc          = [(scrW*(1/2))-(imgW/2) (scrH*(0.8))-(imgH/2) ...
                   (scrW*(1/2))+(imgW/2) (scrH*(0.8))+(imgH/2)];
% Added 12.7, starting with subject 30
if (~isrwded)
    rwdloc(1) = (scrW*(1/3))-(imgW/2);
    rwdloc(3) = (scrW*(1/3))+(imgW/2);
else
    rwdloc(1) = (scrW*(2/3))-(imgW/2);
    rwdloc(3) = (scrW*(2/3))+(imgW/2);
end
boxrect      = rwdloc;
boxrect(1:2) = boxrect(1:2) - 20;
boxrect(3:4) = boxrect(3:4) + 20;
drawbox(1, boxrect);
Screen('DrawTexture', win, rwdTex{isrwded+1, 1}, [0 0 imgW imgH], rwdloc);
Screen('Flip', win);
if (isrwded)
    takeScreenshot(win, '4a_banditPlusImagePlusRewardPlusBox.png');
else
    takeScreenshot(win, '4a_banditPlusImageMinusRewardPlusBox.png');
end

boxTime = min(ITI, 0.5);
pause(boxTime);

imgW    = bandits(thisBandit).dim(2);
imgH    = bandits(thisBandit).dim(1);
Screen('DrawTexture', win, bandits(thisBandit).icon, [0 0 imgW imgH], bandits(thisBandit).loc);
imgW    = imageTex{imgIdx,2}(2);
imgH    = imageTex{imgIdx,2}(1);
imgloc  = [(scrW*(1/2))-(imgW/2) (scrH*(1/2))-(imgH/2) ...
           (scrW*(1/2))+(imgW/2) (scrH*(1/2))+(imgH/2)];
Screen('DrawTexture', win, imageTex{imgIdx,1}, [0 0 imgW imgH], imgloc);
imgW    = rwdTex{isrwded+1, 2}(2);
imgH    = rwdTex{isrwded+1, 2}(1);
rwdloc          = [(scrW*(1/2))-(imgW/2) (scrH*(0.8))-(imgH/2) ...
                   (scrW*(1/2))+(imgW/2) (scrH*(0.8))+(imgH/2)];
% Added 12.7, starting with subject 30
if (~isrwded)
    rwdloc(1) = (scrW*(1/3))-(imgW/2);
    rwdloc(3) = (scrW*(1/3))+(imgW/2);
else
    rwdloc(1) = (scrW*(2/3))-(imgW/2);
    rwdloc(3) = (scrW*(2/3))+(imgW/2);
end
Screen('DrawTexture', win, rwdTex{isrwded+1, 1}, [0 0 imgW imgH], rwdloc);
Screen('Flip', win);

pulses  = cbi_ptb_wait(rwdDispLen, pulses, backtick);
blankscr(win);
pulses  = cbi_ptb_wait(ITI, pulses, backtick);
