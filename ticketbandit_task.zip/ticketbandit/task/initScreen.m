function [scrH scrW] = initScreen(wc)

global win;
global bgcol;
if (~exist('wc'))
    wc = 0;
end
%	rand('twister', sum(clock/randseed));

Screen('Preference', 'SkipSyncTests', 2);

win = Screen('OpenWindow', wc, bgcol);

[scrW scrH] = Screen('WindowSize', win);

if (ismac)
    Screen('TextFont', win, 'Helvetica');
    Screen('TextSize', win, 20);
end

%Screen('TextStyle', win, 0);

KbName('UnifyKeyNames');
DisableKeysForKbCheck([177 227]); % i don't know - it gets stuck sometimes


