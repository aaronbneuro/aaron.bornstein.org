function D = cbi_ptb_devices

%Determine USB device numbers. On Windows and Linux, this is actually irrelevant, since
%KbCheck doesn't use these numbers. For Mac OSX, the cbi_ptb functions will loop through
%all keyboard devices (button-box is also a keyboard device), unless a device number is
%specified.
%
%USAGE: D = cbi_ptb_devices
%
%Sam Gershman, June 2008

persistent DD

if isempty(DD)
    if IsWin || IsLinux
        D = 0;
    else    %mac
        devices = PsychHID('devices');
        D = [];
        for i = 1:length(devices)
            if strcmp(devices(i).usageName,'Keyboard')
                D = [D i];
            end
        end
    end
    DD = D;
else
    D = DD;
end