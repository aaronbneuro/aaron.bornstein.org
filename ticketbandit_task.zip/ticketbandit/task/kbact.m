function a = kbact(to)
% read a action choice from the keyboard with timeout to

global actkeys

a = [];
while length(a) ~= 1
    k = kbget(to);
    if k(10)
        a = -1;
        return;
    elseif ~any(k)
        a = 0;
        return;
    end
    a = find(k(actkeys));
end
