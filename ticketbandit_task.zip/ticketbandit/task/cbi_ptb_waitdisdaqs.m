function [pulses block_start] = cbi_ptb_waitdisdaqs(nDisdaqs,backtick,D)

%Pause until scanner collects the first few volumes. This function will also collect pulse times while waiting.
%
%USAGE: [pulses start_time] = cbi_ptb_waitdisdaqs([nDisdaqs],[backtick],[D])
%
%OPTIONAL INPUTS:
%   nDisdaqs - number of backticks to collect before starting block; if backtick=[], this will
%              be interpreted as the number of seconds to wait
%   backtick - keycode for the back tick (default: KbName('`~'))
%   D - device indices to poll (default: all keyboard devices, including button-box)
%
%OUTPUTS:
%   pulses - vector of pulse times collected while waiting (in system time)
%   block_start - time of the first pulse in absolute (system) time
%
%Sam Gershman, June 2008

global win;
global textcol;

if nargin < 3 || isempty(D)
    D = cbi_ptb_devices;
end

if nargin < 2; try backtick = KbName('`~'); catch backtick = []; end; end
if nargin < 1; nDisdaqs = 3; end

do_countdown = 1;

if (do_countdown)
        DrawFormattedText(win, ['Ready in ' num2str(nDisdaqs) ' seconds...'], 'center', 'center', textcol);
        Screen('Flip', win);
end


k0 = [];
n = 0;
pulses = [];
t = GetSecs; %get the current time
if isempty(backtick)
    timeout = nDisdaqs + t;       %set timeout relative to system time
else
    timeout = t + 1000;
end

while n < nDisdaqs && GetSecs < timeout
    WaitSecs(0.005);
    [r t k] = cbi_ptb_kbcheck(D);       %look for scanner pulse
    if r
        k = k(backtick);
        if ~isempty(backtick) && k && isempty(k0);    %make sure to sample each pulse only once
            n = n + 1;
            pulses = [pulses; t];
		DrawFormattedText(win, num2str(nDisdaqs - n), 'center', 'center', textcol);
		Screen('Flip', win);

        end
    end
    k0 = k;
end

block_start = t;
