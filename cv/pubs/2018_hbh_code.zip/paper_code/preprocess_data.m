%% This script pre-processes all the data.
%% Once this is done, you can run the model fits.
%%
addpath('./data/');
addpath('./fits/');
addpath('./utils/');

% Set to 'true' to re-run the cross-validated discounting fits (takes ~1hr on my laptop).
% Otherwise, it will use the results files saved below.
opts.runLongFits = true; % false;

% Initial parsing / subject exclusions
% Creates _hddm.csv
parse_ITC_csv_withSSLeft('./data/ITC.NYU_563', false, './preprocessed_data/');
parse_ITC_csv_withSSLeft('./data/ITC.cornell_44', true, './preprocessed_data/');

%% Do discounting fits
% Full dataset
fitResults_NYU     = fit_discount_choice('./preprocessed_data/ITC.NYU_563_hddm.csv');
fitResults_cornell = fit_discount_choice('./preprocessed_data/ITC.cornell_44_hddm.csv');

% Discounting-based subject exclusions
k_range = [.00018 .3];

k_NYU = [fitResults_NYU(2,:).k_choice];
badSubjs_NYU = find(k_NYU < k_range(1) | k_NYU > k_range(2));
goodSubjs_NYU = find(k_NYU >= k_range(1) & k_NYU <= k_range(2));
excl_k_NYU   = [fitResults_NYU(2,badSubjs_NYU).subjectID];
fitResults_NYU = fitResults_NYU(:,goodSubjs_NYU);

disp(['ITC.NYU_563: Excluded for k out of range: ' num2str(length(excl_k_NYU))]);
excl_k_NYU

k_cornell = [fitResults_cornell(2,:).k_choice];
badSubjs_cornell  = find(k_cornell < k_range(1) | k_cornell > k_range(2));
goodSubjs_cornell = find(k_cornell >= k_range(1) & k_cornell <= k_range(2));
excl_k_cornell   = [fitResults_cornell(2,badSubjs_cornell).subjectID];
fitResults_cornell = fitResults_cornell(:,goodSubjs_cornell);

save('./fits/fitResults_discounting.mat', 'fitResults_NYU', 'fitResults_cornell');

disp(['ITC.cornell_44: Excluded for k out of range: ' num2str(length(excl_k_cornell))]);
excl_k_cornell

% Remove bad discounters from dataset before making train/test folds
% Creates _postExclusions.csv
removeSubjects('./preprocessed_data/ITC.NYU_563_hddm.csv', excl_k_NYU);
removeSubjects('./preprocessed_data/ITC.cornell_44_hddm.csv', excl_k_cornell);

% Make the training/test datasets
makeFolds('./preprocessed_data/ITC.NYU_563_hddm_postExclusions.csv', 1);
makeFolds('./preprocessed_data/ITC.cornell_44_hddm_postExclusions.csv', 1);

% Fit discounting model to train/test folds
if (opts.runLongFits)
    [~, fitResults_NYU_xval] = fit_disc_xval('dataFile', './preprocessed_data/ITC.NYU_563_hddm_postExclusions', 'outputFile', './fits/fitResults_discounting_NYU_xval.mat');
    [~, fitResults_cornell_xval] = fit_disc_xval('dataFile', './preprocessed_data/ITC.cornell_44_hddm_postExclusions', 'outputFile', './fits/fitResults_discounting_cornell_xval.mat');

    [~, testResults_NYU_xval] = test_disc_xval('fitsFile', './fits/fitResults_discounting_NYU_xval.mat', 'outputFile', './fits/testResults_discounting_NYU_xval.mat');
    [~, testResults_cornell_xval] = test_disc_xval('fitsFile', './fits/fitResults_discounting_cornell_xval.mat', 'outputFile', './fits/testResults_discounting_cornell_xval.mat');
else
    fitResults_NYU_xval = load('./fits/fitResults_discounting_NYU_xval.mat');
    fitResults_NYU_xval = fitResults_NYU_xval.parsedStats;

    fitResults_cornell_xval = load('./fits/fitResults_discounting_cornell_xval.mat');
    fitResults_cornell_xval = fitResults_cornell_xval.parsedStats;

    testResults_NYU_xval = load('./fits/testResults_discounting_NYU_xval.mat');

    testResults_cornell_xval = load('./fits/testResults_discounting_cornell_xval.mat');
end

%% Combine test results
combinedSubjList = sort([testResults_NYU_xval.subjList ; testResults_cornell_xval.subjList]);
testResults_combined = NaN(length(combinedSubjList), 1);

for subjIdx = 1:length(testResults_NYU_xval.subjList);
    subjId = testResults_NYU_xval.subjList(subjIdx);

    testResults_combined(combinedSubjList==subjId) = nansum([testResults_NYU_xval.testStats(subjIdx,:).stat_choice]);
end

for subjIdx = 1:length(testResults_cornell_xval.subjList);
    subjId = testResults_cornell_xval.subjList(subjIdx);

    testResults_combined(combinedSubjList==subjId) = nansum([testResults_cornell_xval.testStats(subjIdx,:).stat_choice]);
end

save('./fits/testResults_discounting_combined_xval.mat', 'testResults_combined');

%% Add the extended columns (incl fit discounting parameter)
% Full dataset
% Creates _fullColumns.csv
addColumns('./preprocessed_data/ITC.NYU_563_hddm_postExclusions', fitResults_NYU(2,:), false);
addColumns('./preprocessed_data/ITC.cornell_44_hddm_postExclusions', fitResults_cornell(2,:), false);

% Train/test folds
addColumns('./preprocessed_data/ITC.NYU_563_hddm_postExclusions', fitResults_NYU_xval, true);
addColumns('./preprocessed_data/ITC.cornell_44_hddm_postExclusions', fitResults_cornell_xval, true);

%% Make the combined files.
% Creates combined_dataset.csv and associated train/test files.
% Full dataset
combinedDataFileName = './preprocessed_data/combined_dataset.csv';
system(['rm -f ' combinedDataFileName]);
system(['touch ' combinedDataFileName]);
system(['head -1 ./preprocessed_data/ITC.cornell_44_hddm_postExclusions_fullColumns.csv >> ' combinedDataFileName]);
system(['cat ./preprocessed_data/ITC.NYU_563_hddm_postExclusions_fullColumns.csv | fgrep -v subj >> ' combinedDataFileName]);
system(['cat ./preprocessed_data/ITC.cornell_44_hddm_postExclusions_fullColumns.csv | fgrep -v subj >> ' combinedDataFileName]);

% Train/test folds
foldFiles = dir('./preprocessed_data/ITC.cornell_44_hddm_postExclusions_train_*fullColumns.csv');   % 96
for foldIdx = 1:length(foldFiles);
    trainFileName = ['./preprocessed_data/combined_dataset_train_' num2str(foldIdx, '%.2d') '.csv'];

    system(['rm -f ' trainFileName]);
    system(['touch ' trainFileName]);
    system(['head -1 ./preprocessed_data/ITC.cornell_44_hddm_postExclusions_fullColumns.csv >> ' trainFileName]);
    system(['cat ./preprocessed_data/ITC.NYU_563_hddm_postExclusions_train_' num2str(foldIdx, '%.2d') '_fullColumns.csv | fgrep -v subj >> ' ...
            trainFileName]);
    system(['cat ./preprocessed_data/ITC.cornell_44_hddm_postExclusions_train_' num2str(foldIdx, '%.2d') '_fullColumns.csv | fgrep -v subj >> ' ...
            trainFileName]);

    testFileName = ['./preprocessed_data/combined_dataset_test_' num2str(foldIdx, '%.2d') '.csv'];
    system(['rm -f ' testFileName]);
    system(['touch ' testFileName]);
    system(['head -1 ./preprocessed_data/ITC.cornell_44_hddm_postExclusions_fullColumns.csv >> ' testFileName]);
    system(['cat ./preprocessed_data/ITC.NYU_563_hddm_postExclusions_test_' num2str(foldIdx, '%.2d') '_fullColumns.csv | fgrep -v subj >> ' ...
            testFileName]);
    system(['cat ./preprocessed_data/ITC.cornell_44_hddm_postExclusions_test_' num2str(foldIdx, '%.2d') '_fullColumns.csv | fgrep -v subj >> ' ...
            testFileName]);

end

% Clean up intermediate files and train/test folds from individual datasets. Leaves only "combined" dataset.
system(['rm -f ./preprocessed_data/ITC.*csv']);
