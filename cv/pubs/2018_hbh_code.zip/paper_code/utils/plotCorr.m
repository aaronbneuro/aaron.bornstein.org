function [rval, pval, dval, robust_res] = plotCorr(x, y, labels, varargin)
% function [rval, pval, dval, robust_res] = plotCorr(x, y, labels, ...)
%
% plot R(x,y)
%

opts = parse_args(varargin, 'corrType', {'Pearson'}, ...
                            'corrCoef', [], ...
                            'plotSig', false, ...
                            'bigDots', false, ...
                            'plotRobust', false, ...
                            'plotSmallData', false, ...
                            'squareAxes', false);

if (opts.plotSmallData)
    opts.bigDots = true;
    opts.squareAxes = true;
end

if (iscell(opts.corrType))
    opts.corrType = opts.corrType{:};
end

if (iscell(opts.corrCoef))
    opts.corrCoef = opts.corrCoef{:};
end

if (isempty(opts.corrCoef))
    if (~isempty(strfind(opts.corrType, 'Pearson')))
        opts.corrCoef='\it{R}';
    elseif (~isempty(strfind(opts.corrType, 'Spearman')))
        opts.corrCoef='\rho';
    elseif (~isempty(strfind(opts.corrType, 'Kendall')))
        opts.corrCoef='\tau';
    end
end

if (opts.plotRobust)
    opts.corrCoef = ['robust ' opts.corrCoef];
end

[rval,pval] = corr(x, y, 'type', opts.corrType);

if ((nargout > 2) && (exist('cohend') == 2))
    dval = cohend(x, y, true);
end

if ((nargout > 3 || opts.plotRobust) && (exist('skipped_correlation') == 2))
    [robust_res.r, robust_res.t, robust_res.h, robust_res.outid, robust_res.hboot, robust_res.CI] = skipped_correlation(x, y, false);

    if (opts.plotRobust)
        includeVals = true(1, length(x));
        includeVals(robust_res.outid{1}) = false;

        x = x(includeVals);
        y = y(includeVals);

        rval = getfield(robust_res.r, opts.corrType);
        pval = 1-tcdf(abs(getfield(robust_res.t, opts.corrType)), sum(includeVals)-1);
    end
end

aaron_newfig;
set(gca, 'FontSize', 32);
set(gca, 'FontWeight', 'demi');
hold on;

if (opts.bigDots)
    plot(x, y, 'ko', 'LineWidth', 8, 'MarkerSize', 8);
else
    plot(x, y, 'ko');
end

if (opts.squareAxes)
    axis square
else
    axis tight
end

h=lsline;
xlabel(labels{1});
ylabel(labels{2});

if (opts.plotSig && pval<0.05)
    midX=mean(get(gca, 'XLim'));
    yl=get(gca, 'YLim');
    midY=yl(2)+(diff(yl)*.25);

    plot(midX, midY, 'k*', 'MarkerSize', 18, 'LineWidth', 2);
end
legend(h, [opts.corrCoef fmtval(rval) ', \it{P}' fmtval(pval)], 'Location', 'NorthOutside');
