function sfmt = fmtval(x)

if (abs(x) < .001)
    sfmt = ['<.001'];
else
    sfmt = ['=' strrep(num2str(round(x,3)),'0.','.')];
end

