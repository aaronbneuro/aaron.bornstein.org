function set_axis_opts(ah, bgcol)

lg = bgcol;

set(ah, 'XColor', 'Black')
set(ah, 'YColor', 'Black')
set(ah, 'Color', lg)
set(ah, 'FontSize', 14);
set(ah, 'FontWeight', 'demi');
set(ah, 'LineWidth', 2);
